const CLAVE_STORAGE = 'contactos';

// ---------- localStorage ----------
function obtenerContactos() {
    try {
        return JSON.parse(localStorage.getItem(CLAVE_STORAGE)) || [];
    } catch (e) {
        return [];
    }
}

function guardarContacto(contacto) {
    const contactos = obtenerContactos();
    contactos.push(contacto);
    localStorage.setItem(CLAVE_STORAGE, JSON.stringify(contactos));
}

// ---------- Formulario (index.html) ----------
const formulario = document.getElementById('formulario-reserva');

if (formulario) {
    const mensaje = document.getElementById('mensaje');

    formulario.addEventListener('submit', function (e) {
        e.preventDefault();

        const datos = {
            nombre: document.getElementById('nombre').value.trim(),
            correo: document.getElementById('correo').value.trim(),
            celular: document.getElementById('celular').value.trim()
        };

        try {
            guardarContacto(datos);
            mensaje.textContent = 'Datos guardados correctamente';
            mensaje.className = 'mensaje ok';
            formulario.reset();
        } catch (error) {
            mensaje.textContent = 'No se pudieron guardar los datos';
            mensaje.className = 'mensaje error';
        }
    });
}

// ---------- Slider con paginación (index.html) ----------
const slideImg = document.getElementById('slide-img');

if (slideImg) {
    const puntos = document.querySelectorAll('.punto');
    const imagenes = [
        { src: 'imagen/menu%20del%20dia.jpg', alt: 'Menú del día' },
        { src: 'imagen/ceviche%20fresco.jpg', alt: 'Ceviche fresco' },
        { src: 'imagen/parrilla.jpg', alt: 'Parrillas' }
    ];

    let actual = 0;
    let temporizador = null;

    function mostrar(i) {
        actual = (i + imagenes.length) % imagenes.length;
        slideImg.src = imagenes[actual].src;
        slideImg.alt = imagenes[actual].alt;
        puntos.forEach(p => p.classList.remove('activo'));
        puntos[actual].classList.add('activo');
    }

    function automatico() {
        clearInterval(temporizador);
        temporizador = setInterval(function () {
            mostrar(actual + 1);
        }, 4000);
    }

    puntos.forEach(function (punto, i) {
        punto.addEventListener('click', function () {
            mostrar(i);
            automatico();
        });
    });

    mostrar(0);
    automatico();
}

// ---------- Tabla de contactos (contacts.html) ----------
const lista = document.getElementById('lista-contactos');

if (lista) {
    const guardados = obtenerContactos();

    if (guardados.length === 0) {
        const fila = document.createElement('tr');
        const celda = document.createElement('td');
        celda.colSpan = 3;
        celda.textContent = 'No hay contactos registrados';
        fila.appendChild(celda);
        lista.appendChild(fila);
    } else {
        guardados.forEach(function (c) {
            const fila = document.createElement('tr');
            [c.nombre, c.correo, c.celular].forEach(function (valor) {
                const celda = document.createElement('td');
                celda.textContent = valor;
                fila.appendChild(celda);
            });
            lista.appendChild(fila);
        });
    }
}