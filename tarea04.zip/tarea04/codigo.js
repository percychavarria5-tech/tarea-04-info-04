const CLAVE_STORAGE = 'contactos';
const URL_SERVIDOR = 'http://167.71.101.78/senati/fpw/reserva.php';

// ---------- Utilidades de localStorage ----------
function obtenerContactos() {
    try {
        return JSON.parse(localStorage.getItem(CLAVE_STORAGE)) || [];
    } catch (e) {
        return [];
    }
}

function guardarContacto(contacto) {
    const contactos = obtenerContactos();
    contactos.push(contacto);
    localStorage.setItem(CLAVE_STORAGE, JSON.stringify(contactos));
}

// ---------- Formulario (index.html) ----------
const formulario = document.getElementById('formulario-reserva');

if (formulario) {
    const nombre = document.getElementById('nombre');
    const correo = document.getElementById('correo');
    const celular = document.getElementById('celular');
    const mensaje = document.getElementById('mensaje');
    const botonEnviar = document.getElementById('boton-enviar');

    function mostrarMensaje(texto, tipo) {
        mensaje.textContent = texto;
        mensaje.className = 'mensaje ' + tipo;
    }

    formulario.addEventListener('submit', function (e) {
        e.preventDefault();

        const datos = {
            nombre: nombre.value.trim(),
            correo: correo.value.trim(),
            celular: celular.value.trim()
        };

        botonEnviar.disabled = true;
        botonEnviar.textContent = 'Enviando...';

        fetch(URL_SERVIDOR, {
            method: 'POST',
            body: JSON.stringify(datos),
            headers: { 'Content-type': 'application/json; charset=UTF-8' }
        })
            .then(response => response.json())
            .then(data => {
                console.log(data);
                if (data.status === 200) {
                    guardarContacto(datos);
                    mostrarMensaje('SE REGISTRÓ SATISFACTORIAMENTE', 'ok');
                    formulario.reset();
                } else {
                    mostrarMensaje('Error: ' + data.message, 'error');
                }
            })
            .catch(error => {
                console.log(error);
                mostrarMensaje('No se pudo conectar con el servidor.', 'error');
            })
            .finally(() => {
                botonEnviar.disabled = false;
                botonEnviar.textContent = 'Enviar';
            });
    });
}

// ---------- Slide (index.html) ----------
const banner = document.getElementById('banner');

if (banner) {
    const puntos = document.querySelectorAll('.punto');
    const botonAnterior = document.getElementById('anterior');
    const botonSiguiente = document.getElementById('siguiente');

    // Usa fotos que ya tienes en la carpeta imagen/
    const slides = [
        { titulo: 'OFERTAS',      texto: 'Laptops y videojuegos en oferta',      imagen: 'imagen/videojuego.jpg' },
        { titulo: 'ULTRABOOKS',   texto: 'Ligeras, rápidas y elegantes',         imagen: 'imagen/ultrabook.png' },
        { titulo: 'CONSOLAS',     texto: 'Las mejores consolas al mejor precio', imagen: 'imagen/consola.jpg' },
        { titulo: 'ELIGE TU LAPTOP', texto: 'Asesoría para comprar sin errores', imagen: 'imagen/noticia2.png' }
    ];

    let indiceActual = 0;
    let temporizador = null;

    function mostrarSlide(i) {
        indiceActual = (i + slides.length) % slides.length;
        const s = slides[indiceActual];

        document.getElementById('banner-titulo').textContent = s.titulo;
        document.getElementById('banner-texto').textContent = s.texto;

        // capa oscura de izquierda a derecha para que el texto se lea
        banner.style.backgroundImage =
            'linear-gradient(90deg, rgba(20,10,60,0.85) 0%, rgba(20,10,60,0.35) 60%, rgba(20,10,60,0.1) 100%), url("' + s.imagen + '")';

        puntos.forEach(p => p.classList.remove('activo'));
        puntos[indiceActual].classList.add('activo');
    }

    function iniciarAutomatico() {
        clearInterval(temporizador);
        temporizador = setInterval(function () {
            mostrarSlide(indiceActual + 1);
        }, 5000);
    }

    puntos.forEach(function (punto, i) {
        punto.addEventListener('click', function () {
            mostrarSlide(i);
            iniciarAutomatico();
        });
    });

    botonAnterior.addEventListener('click', function () {
        mostrarSlide(indiceActual - 1);
        iniciarAutomatico();
    });

    botonSiguiente.addEventListener('click', function () {
        mostrarSlide(indiceActual + 1);
        iniciarAutomatico();
    });

    // pausa al pasar el mouse
    banner.addEventListener('mouseenter', () => clearInterval(temporizador));
    banner.addEventListener('mouseleave', iniciarAutomatico);

    mostrarSlide(0);
    iniciarAutomatico();
}

// ---------- Tabla de contactos (contacts.html) ----------
const lista = document.getElementById('lista-contactos');

if (lista) {
    const guardados = obtenerContactos();

    if (guardados.length === 0) {
        const fila = document.createElement('tr');
        const celda = document.createElement('td');
        celda.colSpan = 3;
        celda.textContent = 'No hay contactos registrados';
        fila.appendChild(celda);
        lista.appendChild(fila);
    } else {
        guardados.forEach(function (c) {
            const fila = document.createElement('tr');
            [c.nombre, c.correo, c.celular].forEach(function (valor) {
                const celda = document.createElement('td');
                celda.textContent = valor;
                fila.appendChild(celda);
            });
            lista.appendChild(fila);
        });
    }
}